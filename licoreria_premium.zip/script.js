
function scrollToCatalog() {
    document.getElementById('catalogo').scrollIntoView({ behavior: 'smooth' });
}
function buscarProducto() {
    let input = document.getElementById('buscador').value.toLowerCase();
    let productos = document.querySelectorAll('.producto');
    productos.forEach(p => {
        let nombre = p.querySelector('h3').textContent.toLowerCase();
        p.style.display = nombre.includes(input) ? 'block' : 'none';
    });
}
function filtrar(tipo) {
    let productos = document.querySelectorAll('.producto');
    productos.forEach(p => {
        p.style.display = (tipo === 'todos' || p.dataset.tipo === tipo) ? 'block' : 'none';
    });
}
function agregarCarrito(producto) {
    alert(producto + ' añadido al carrito');
}
